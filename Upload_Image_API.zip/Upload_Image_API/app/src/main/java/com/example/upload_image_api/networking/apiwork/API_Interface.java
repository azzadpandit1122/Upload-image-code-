package com.example.upload_image_api.networking.apiwork;

import com.example.upload_image_api.model.UploadResponse;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface API_Interface {

//    https://sapna.dev.nojoto.com/api/beta/content.php
    @Multipart
    @POST("api/beta/content.php")
    Call<UploadResponse> uploadImage(
            @Query("cid") String cid,
            @Query("type") String media,
            @Part MultipartBody.Part image
            //@Part("banner") RequestBody requestBody
    );


}
